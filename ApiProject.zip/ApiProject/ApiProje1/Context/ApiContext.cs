﻿using ApiProje1.Entities;
using Microsoft.EntityFrameworkCore;

namespace ApiProje1.Context
{
    public class ApiContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=10.20.103.28,1433;Database=ApiProjeDb;User ID=SA;Password=Softito1882;Trusted_Connection=False;Encrypt=False;");
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Product> Products { get; set; }

    }
}
