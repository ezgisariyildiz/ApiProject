﻿namespace ApiProje1.DTOs.ProductsDtos
{
    public class GetByIdProductDto
    {
        public string Name { get; set; }
    }
}
