﻿namespace ApiProje1.DTOs.ProductsDtos
{
    public class UpdateProductDto
    {
        public int ProductId { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
    }
}