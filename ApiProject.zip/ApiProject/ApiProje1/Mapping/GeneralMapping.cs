﻿using ApiProje1.DTOs.CategoryDto;
using ApiProje1.DTOs.EmployeeDto;
using ApiProje1.DTOs.ProductsDtos;
using ApiProje1.Entities;
using AutoMapper;

namespace ApiProje1.Mapping
{
    public class GeneralMapping : Profile
    {
        public GeneralMapping()
        {
            //eşleştirme işlemi yapıyoruz, employee, result ile eşleşsin ReverseMap ile de tam tersi yani, Result ile employee de eşleşsin işlemi yapılır
            CreateMap<Employee, ResultEmployeeDto>().ReverseMap();
            CreateMap<Employee, CreateEmployeeDto>().ReverseMap();
            CreateMap<Employee, UpdateEmployeeDto>().ReverseMap();
            CreateMap<Employee, GetByIdEmployeeDto>().ReverseMap();

            CreateMap<Category, CreateCategoryDto>().ReverseMap();

            CreateMap<Product, CreateProductDto>().ReverseMap();
            CreateMap<Product, ResultProductDto>().ForMember(x => x.CategoryName, y => y.MapFrom(z => z.Category.Name)).ReverseMap();
        }
    }
}
