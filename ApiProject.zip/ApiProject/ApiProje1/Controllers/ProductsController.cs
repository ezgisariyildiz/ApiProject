﻿using ApiProje1.Context;
using ApiProje1.DTOs.ProductsDtos;
using ApiProje1.Entities;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiProje1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApiContext _context;
        private readonly IMapper _mapper;

        public ProductsController(ApiContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetProduct()
        {
            var result = _context.Products.Include(x => x.Category).ToList();
            return Ok(_mapper.Map<List<ResultProductDto>>(result));
        }

        [HttpPost]
        public IActionResult CreateProductDto(CreateProductDto productDto)
        {
            var value = _mapper.Map<Product>(productDto);
            _context.Products.Add(value);
            _context.SaveChanges();
            return Ok("Ekleme işlemi başarılı");
        }

        //Aynı tipte iki tana attribüte kullanamazsın HttpGet in yanına GetByIdProduct yazmamız gerekiyor
        [HttpGet("GetByIdProduct")]
        public IActionResult GetByIdProductDto(int id)
        {
            var deger = _context.Products.Find(id);
            GetByIdProductDto get = new GetByIdProductDto();
            get.Name = deger.Name;
            return Ok(get);
        }

        [HttpPut]
        public IActionResult UpdateProduct(UpdateProductDto productDto, int id)
        {
            var deger = _context.Products.Find(id);
            deger.Stock = productDto.Stock;
            deger.Price = productDto.Price;
            _context.SaveChanges();
            return Ok("Güncelleme işlemi başarılı...");
        }

        [HttpDelete]
        public IActionResult DeleteProductDto(int id)
        {
            var deger = _context.Products.Find(id);
            _context.Products.Remove(deger);
            _context.SaveChanges();
            return Ok("Başarıyla silindi");
        }
    }
}
