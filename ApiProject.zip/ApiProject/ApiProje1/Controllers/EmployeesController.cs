﻿using ApiProje1.Context;
using ApiProje1.DTOs.EmployeeDto;
using ApiProje1.Entities;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiProje1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly ApiContext _apiContext;
        private readonly IMapper _mapper;

        public EmployeesController(ApiContext apiContext, IMapper mapper)
        {
            _apiContext = apiContext;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult EmployeeList()
        {
            var sonuc = _apiContext.Employees.ToList();
            return Ok(_mapper.Map<List<ResultEmployeeDto>>(sonuc));
        }

        [HttpPost]
        public IActionResult CreateEmployee(CreateEmployeeDto createEmployeeDto)
        {
            var deger = _mapper.Map<Employee>(createEmployeeDto);//employee ve dto arasındaki uyumu sağlamaya çalışıyoruz
            _apiContext.Employees.Add(deger);
            _apiContext.SaveChanges();
            return Ok("Başarılı bir şekilde eklendi");

        }

        [HttpDelete]
        public IActionResult DeleteEmployee(int id)
        {
            var deger = _apiContext.Employees.Find(id);
            _apiContext.Employees.Remove(deger);
            _apiContext.SaveChanges();
            return Ok("Başarılı bir şekilde silindi.");
        }

        [HttpGet("GetByIdEmployee")]
        public IActionResult GetByIdEmployee(int id)
        {
            var deger = _apiContext.Employees.Find(id);
            return Ok(_mapper.Map<GetByIdEmployeeDto>(deger));
        }

        [HttpPut]
        public IActionResult UpdateEmployee(UpdateEmployeeDto updateEmployeeDto, int id)
        {
            var sonuc = _apiContext.Employees.Find(id);
                       //Map(kaynak, varış noktası)
            _mapper.Map(updateEmployeeDto, sonuc);//dto:kaynak, sonuc:varış noktası
            _apiContext.Employees.Update(sonuc);
            _apiContext.SaveChanges();
            return Ok("Başarılı bir şekilde güncellendi.");
        }

    }
}
