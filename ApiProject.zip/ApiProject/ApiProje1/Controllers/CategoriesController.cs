﻿using ApiProje1.Context;
using ApiProje1.DTOs.CategoryDto;
using ApiProje1.Entities;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiProje1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ApiContext _context;
        private readonly IMapper _mapper;

        public CategoriesController(ApiContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult CategoryList()
        {
            var result = _context.Categories.ToList();
            return Ok(result);
        }

        [HttpPost]
        public IActionResult CreateCategory(CreateCategoryDto categoryDto)
        {
            var deger = _mapper.Map<Category>(categoryDto);
            _context.Categories.Add(deger);
            _context.SaveChanges();
            return Ok("Ekleme işlemi başarılı");
        }

        //Aynı tipte iki tana attribüte kullanamazsın HttpGet in yanına GetByIdCategory yazmamız gerekiyor
        [HttpGet("GetByIdCategory")]
        public IActionResult GetByIdCategoryDto(int id)
        {
            var deger = _context.Categories.Find(id);
            return Ok(deger);
        }

        [HttpPut]
        public IActionResult UpdateCategory(UpdateCategoryDto categoryDto, int id)
        {
            var deger = _context.Categories.Find(id);
            deger.Name = categoryDto.Name;
            deger.Description = categoryDto.Description;
            _context.SaveChanges();
            return Ok("Güncelleme işlemi başarılı...");
        }


        [HttpDelete]
        public IActionResult DeleteCategory(int id)
        {
            var deger = _context.Categories.Find(id);
             _context.Categories.Remove(deger);
            _context.SaveChanges();
            return Ok("Başarıyla silindi");
        }
    }
}
